Testeando la creacion
        7.1                 : AquaCrop Version (March 2017)
        61                 : CN (Curve Number)
        7                 : Readily evaporative water from top layer (mm)
        1                 : number of soil horizons
       -9                   : variable no longer applicable
  Thickness  Sat   FC    WP     Ksat   Penetrability  Gravel  CRa       CRb           description
  ---(m)-   ----(vol %)-----  (mm/day)      (%)        (%)    -----------------------------------------
    1.5    40  30  20   400        100         0     0.5  0.4         
